package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.PlannerViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SessionPlannerTest {

    private lateinit var context: Context
    private lateinit var app: Application

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        app = context as Application
        // Clear preferences to guarantee hermetic test conditions
        val prefs = context.getSharedPreferences("axis_auth_preferences", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
    }

    // 1. Session restored after program/device restart
    @Test
    fun testSessionRestoredAfterRestart() = runBlocking {
        // Create initial viewmodel and perform sign in
        val viewModel1 = PlannerViewModel(app)
        assertFalse(viewModel1.isLoggedIn.value)

        viewModel1.login("Workspace (workharishragav@gmail.com)")
        assertTrue(viewModel1.isLoggedIn.value)
        assertEquals("Workspace (workharishragav@gmail.com)", viewModel1.loginType.value)

        // Create a new viewmodel instance simulating application launch restart
        val viewModel2 = PlannerViewModel(app)
        assertTrue("Session must be successfully restored upon app restart", viewModel2.isLoggedIn.value)
        assertEquals("Workspace (workharishragav@gmail.com)", viewModel2.loginType.value)
    }

    // 2. Logout clears the active session completely
    @Test
    fun testLogoutClearsActiveSession() = runBlocking {
        val viewModel = PlannerViewModel(app)
        viewModel.login("Workspace (workharishragav@gmail.com)")
        assertTrue(viewModel.isLoggedIn.value)

        viewModel.logout()
        assertFalse("Logged in state should be false after logout", viewModel.isLoggedIn.value)
        assertEquals("", viewModel.loginType.value)

        // Verify cleared state persists across simulated restart too
        val restartedViewModel = PlannerViewModel(app)
        assertFalse("Session remains completely cleared upon app restart", restartedViewModel.isLoggedIn.value)
        assertEquals("", restartedViewModel.loginType.value)
    }

    // 3. Verify Google login is identified and honestly reported
    @Test
    fun verifyGoogleAuthenticationNotFaked() {
        val viewModel = PlannerViewModel(app)
        assertFalse("No fake sign-in state on startup", viewModel.isLoggedIn.value)
        assertEquals("", viewModel.loginType.value)
    }

    // 4. Verify visual configuration setup
    @Test
    fun verifyAXISAppNameAndBranding() {
        val appName = context.getString(R.string.app_name)
        assertEquals("AXIS", appName)
    }
}
