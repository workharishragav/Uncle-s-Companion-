package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.PlannerDao
import com.example.data.local.PlannerDatabase
import com.example.data.model.RoutineActivity
import com.example.data.model.Task
import com.example.data.repository.PlannerRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: PlannerDatabase
    private lateinit var dao: PlannerDao
    private lateinit var repository: PlannerRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, PlannerDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.plannerDao
        repository = PlannerRepository(dao)
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AXIS", appName)
    }

    // 1. Routine items are inserted only once per date.
    @Test
    fun testRoutineItemsInsertedOnlyOnce() = runBlocking {
        val date = "2026-05-31"
        
        // Concurrently run insertions to simulate duplication stress
        val job1 = launch { repository.initializeRoutineForDateIfEmpty(date) }
        val job2 = launch { repository.initializeRoutineForDateIfEmpty(date) }
        job1.join()
        job2.join()
        
        // Also call normally
        repository.initializeRoutineForDateIfEmpty(date)
        
        val routines = dao.getRoutineActivitiesByDate(date).first()
        assertEquals("Should have exactly 11 default routines", 11, routines.size)
        
        // Ensure no duplicates exist by asserting block names are unique
        val uniqueBlockNames = routines.map { it.blockName }.toSet()
        assertEquals("Block names should be unique", 11, uniqueBlockNames.size)
    }

    // 2. Today screen loads the correct tasks for the selected date.
    @Test
    fun testLoadingTasksForSelectedDate() = runBlocking {
        val todayStr = "2026-05-31"
        val tomorrowStr = "2026-06-01"
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        
        val todayMillis = format.parse(todayStr)!!.time
        val tomorrowMillis = format.parse(tomorrowStr)!!.time
        
        val task1 = Task(id = 1, title = "Task for Today", targetDate = todayMillis, priority = "A")
        val task2 = Task(id = 2, title = "Task for Tomorrow", targetDate = tomorrowMillis, priority = "B")
        
        dao.insertTask(task1)
        dao.insertTask(task2)
        
        val allTasks = dao.getAllTasks().first()
        assertEquals(2, allTasks.size)
        
        // Simulated UI Filtering logic as implemented in TodayScreen.kt
        val filteredForToday = allTasks.filter { task ->
            if (task.associatedDay != null) {
                false
            } else {
                val taskDateStr = format.format(Date(task.targetDate))
                taskDateStr == todayStr
            }
        }
        
        assertEquals(1, filteredForToday.size)
        assertEquals("Task for Today", filteredForToday[0].title)
    }

    // 3. Completed or Total updates correctly when a task is checked.
    @Test
    fun testProgressCounterUpdatesOnTaskToggle() = runBlocking {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateMillis = format.parse("2026-05-31")!!.time
        
        val task1 = Task(id = 1, title = "Strategic Goal 1", targetDate = dateMillis, isCompleted = false)
        val task2 = Task(id = 2, title = "Strategic Goal 2", targetDate = dateMillis, isCompleted = false)
        
        dao.insertTask(task1)
        dao.insertTask(task2)
        
        var list = dao.getAllTasks().first()
        var completedCount = list.count { it.isCompleted }
        var totalCount = list.size
        assertEquals(0, completedCount)
        assertEquals(2, totalCount)
        
        // Toggle task1 to completed
        dao.insertTask(task1.copy(isCompleted = true))
        
        list = dao.getAllTasks().first()
        completedCount = list.count { it.isCompleted }
        totalCount = list.size
        assertEquals(1, completedCount)
        assertEquals(2, totalCount)
    }

    // 4. Data persists after app restart.
    @Test
    fun testDataPersistenceAcrossSessionRestarts() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        
        // Create persistent-styled database (not in-memory, but using custom name in Room test environment)
        val persistentDb = Room.databaseBuilder(context, PlannerDatabase::class.java, "test_persistence_db")
            .allowMainThreadQueries()
            .build()
        
        val testTask = Task(id = 99, title = "Persistent Task", isCompleted = true)
        persistentDb.plannerDao.insertTask(testTask)
        
        // Simulate closing the app/database connection
        persistentDb.close()
        
        // Re-open and verify
        val restoredDb = Room.databaseBuilder(context, PlannerDatabase::class.java, "test_persistence_db")
            .allowMainThreadQueries()
            .build()
        
        val restoredTasks = restoredDb.plannerDao.getAllTasks().first()
        assertTrue(restoredTasks.any { it.id == 99 && it.title == "Persistent Task" && it.isCompleted })
        
        restoredDb.close()
    }
}
