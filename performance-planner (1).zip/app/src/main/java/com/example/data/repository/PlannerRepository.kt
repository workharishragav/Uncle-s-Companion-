package com.example.data.repository

import com.example.data.local.PlannerDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class PlannerRepository(private val plannerDao: PlannerDao) {

    private val initializationMutex = Mutex()

    // --- RPM Pillars ---
    val allRpmPillars: Flow<List<RpmPillar>> = plannerDao.getAllRpmPillars()

    suspend fun insertRpmPillar(pillar: RpmPillar) {
        plannerDao.insertRpmPillar(pillar)
    }

    suspend fun updateRpmPillar(pillar: RpmPillar) {
        plannerDao.updateRpmPillar(pillar)
    }

    suspend fun deleteRpmPillar(id: Int) {
        plannerDao.deleteRpmPillarById(id)
    }

    // --- Monthly Goals ---
    fun getMonthlyGoals(year: Int, month: Int): Flow<List<MonthlyGoal>> {
        return plannerDao.getMonthlyGoals(year, month)
    }

    suspend fun insertMonthlyGoal(goal: MonthlyGoal) {
        plannerDao.insertMonthlyGoal(goal)
    }

    suspend fun updateMonthlyGoal(goal: MonthlyGoal) {
        plannerDao.updateMonthlyGoal(goal)
    }

    suspend fun deleteMonthlyGoal(id: Int) {
        plannerDao.deleteMonthlyGoalById(id)
    }

    // --- Weekly Goals ---
    fun getWeeklyGoals(year: Int, week: Int): Flow<List<WeeklyGoal>> {
        return plannerDao.getWeeklyGoals(year, week)
    }

    suspend fun insertWeeklyGoal(goal: WeeklyGoal) {
        plannerDao.insertWeeklyGoal(goal)
    }

    suspend fun updateWeeklyGoal(goal: WeeklyGoal) {
        plannerDao.updateWeeklyGoal(goal)
    }

    suspend fun deleteWeeklyGoal(id: Int) {
        plannerDao.deleteWeeklyGoalById(id)
    }

    // --- Tasks ---
    val allTasks: Flow<List<Task>> = plannerDao.getAllTasks()
    val weeklyScheduledTasks: Flow<List<Task>> = plannerDao.getWeeklyScheduledTasks()

    suspend fun insertTask(task: Task) {
        plannerDao.insertTask(task)
    }

    suspend fun updateTask(task: Task) {
        plannerDao.updateTask(task)
    }

    suspend fun deleteTask(id: Int) {
        plannerDao.deleteTaskById(id)
    }

    // --- Routine Activities ---
    fun getRoutineActivitiesByDate(date: String): Flow<List<RoutineActivity>> {
        return plannerDao.getRoutineActivitiesByDate(date)
    }

    suspend fun updateRoutineActivity(activity: RoutineActivity) {
        plannerDao.updateRoutineActivity(activity)
    }

    suspend fun initializeRoutineForDateIfEmpty(date: String) {
        initializationMutex.withLock {
            val currentList = plannerDao.getRoutineActivitiesByDate(date).first()
            if (currentList.isEmpty()) {
                val defaults = listOf(
                    RoutineActivity(date = date, blockName = "05:00 AM - 05:15 AM: Victory Hour & Gratitude", type = "HABIT", displayOrder = 1),
                    RoutineActivity(date = date, blockName = "05:15 AM - 05:50 AM: S.A.V.E.R.S Routine (Silence, Affirm, Visual, Write)", type = "HABIT", displayOrder = 2),
                    RoutineActivity(date = date, blockName = "06:15 AM - 08:00 AM: Morning Gym & Badminton Workouts", type = "HABIT", displayOrder = 3),
                    RoutineActivity(date = date, blockName = "08:30 AM - 09:00 AM: Office Prep & Commute", type = "WORKFLOW", displayOrder = 4),
                    RoutineActivity(date = date, blockName = "09:00 AM - 09:30 AM: Traffic University (Strangest Secret tape)", type = "WORKFLOW", displayOrder = 5),
                    RoutineActivity(date = date, blockName = "09:30 AM - 11:00 AM: Focus 90/90/1 Rule (Total Bubble Focus)", type = "WORKFLOW", displayOrder = 6),
                    RoutineActivity(date = date, blockName = "11:00 AM - 01:00 PM: Focus 60/10 Rule (Elite Execution)", type = "WORKFLOW", displayOrder = 7),
                    RoutineActivity(date = date, blockName = "02:00 PM - 04:00 PM: Focus 60/10 (Critical Meetings & Admin)", type = "WORKFLOW", displayOrder = 8),
                    RoutineActivity(date = date, blockName = "04:00 PM - 06:00 PM: Adminstrivia & 5 PM Next Day planning", type = "WORKFLOW", displayOrder = 9),
                    RoutineActivity(date = date, blockName = "07:30 PM - 09:30 PM: Offline, Family Connections & Nature Walk", type = "HABIT", displayOrder = 10),
                    RoutineActivity(date = date, blockName = "09:30 PM - 10:00 PM: Nightly Journal Debrief, Expenses & Goals", type = "HABIT", displayOrder = 11)
                )
                plannerDao.insertRoutineActivities(defaults)
            }
        }
    }

    // --- Nightly Reflections ---
    fun getNightlyReflectionByDate(date: String): Flow<NightlyReflection?> {
        return plannerDao.getNightlyReflectionByDate(date)
    }

    suspend fun insertNightlyReflection(reflection: NightlyReflection) {
        plannerDao.insertNightlyReflection(reflection)
    }
}
