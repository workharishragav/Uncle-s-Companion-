package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rpm_pillars")
data class RpmPillar(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val topic: String,
    val category: String, // e.g., "Plant Operations", "Ensinger Culture", "Team Setup", "Team Development", "Financial FY26-27"
    val result: String, // Desired Result / Outcome
    val purpose: String, // Core Purpose
    val priority: String = "Medium", // Priority level: "High", "Medium", "Low"
    val duration: String = "", // e.g., "2 hours", "Daily" 
    val targetDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "monthly_goals")
data class MonthlyGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val year: Int,
    val month: Int, // 1 - 12
    val goalNumber: Int, // 1 to 5
    val content: String,
    val isCompleted: Boolean = false
)

@Entity(tableName = "weekly_goals")
data class WeeklyGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val year: Int,
    val weekOfYear: Int,
    val goalNumber: Int, // 1 to 5
    val content: String,
    val isCompleted: Boolean = false,
    val isNextWeek: Boolean = false // If true, belongs to the "Next Week" bucket
)

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val targetDate: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val category: String = "General", // "RPM", "Monthly_Todo", "Weekly_Todo", "General"
    val rpmPillarId: Int? = null, // Links task directly to an RPM Topic
    val priority: String = "B", // Tony Robbins Style or Standard: "A" (Top Priority), "B", "C"
    val duration: String = "", // Estimated duration
    val associatedDay: String? = null // For Weekly planner association: "Monday", "Tuesday", etc.
)

@Entity(tableName = "routine_activities")
data class RoutineActivity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // "YYYY-MM-DD"
    val blockName: String, // e.g. "5:00 AM - 5:15 AM: Victory Hour"
    val type: String, // "HABIT" or "WORKFLOW"
    val isCompleted: Boolean = false,
    val displayOrder: Int = 0
)

@Entity(tableName = "nightly_reflections")
data class NightlyReflection(
    @PrimaryKey val date: String, // "YYYY-MM-DD"
    val planVsActual: String = "",
    val didVictoryHour: Boolean = false,
    val didSavers: Boolean = false,
    val rating: Int = 5, // Rating out of 10
    val expensesLogged: Boolean = false,
    val portfolioChecked: Boolean = false,
    val notes: String = ""
)
