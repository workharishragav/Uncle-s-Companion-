package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlannerDao {

    // --- RPM Pillars ---
    @Query("SELECT * FROM rpm_pillars ORDER BY priority DESC, topic ASC")
    fun getAllRpmPillars(): Flow<List<RpmPillar>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRpmPillar(pillar: RpmPillar)

    @Update
    suspend fun updateRpmPillar(pillar: RpmPillar)

    @Query("DELETE FROM rpm_pillars WHERE id = :id")
    suspend fun deleteRpmPillarById(id: Int)

    // --- Monthly Goals ---
    @Query("SELECT * FROM monthly_goals WHERE year = :year AND month = :month ORDER BY goalNumber ASC")
    fun getMonthlyGoals(year: Int, month: Int): Flow<List<MonthlyGoal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMonthlyGoal(goal: MonthlyGoal)

    @Update
    suspend fun updateMonthlyGoal(goal: MonthlyGoal)

    @Query("DELETE FROM monthly_goals WHERE id = :id")
    suspend fun deleteMonthlyGoalById(id: Int)

    // --- Weekly Goals ---
    @Query("SELECT * FROM weekly_goals WHERE year = :year AND weekOfYear = :week ORDER BY isNextWeek ASC, goalNumber ASC")
    fun getWeeklyGoals(year: Int, week: Int): Flow<List<WeeklyGoal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeeklyGoal(goal: WeeklyGoal)

    @Update
    suspend fun updateWeeklyGoal(goal: WeeklyGoal)

    @Query("DELETE FROM weekly_goals WHERE id = :id")
    suspend fun deleteWeeklyGoalById(id: Int)

    // --- Tasks ---
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, priority ASC, targetDate DESC")
    fun getAllTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE associatedDay IS NOT NULL")
    fun getWeeklyScheduledTasks(): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Int)

    // --- Routine Activities ---
    @Query("SELECT * FROM routine_activities WHERE date = :date ORDER BY displayOrder ASC")
    fun getRoutineActivitiesByDate(date: String): Flow<List<RoutineActivity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutineActivities(activities: List<RoutineActivity>)

    @Update
    suspend fun updateRoutineActivity(activity: RoutineActivity)

    // --- Nightly Reflections ---
    @Query("SELECT * FROM nightly_reflections WHERE date = :date")
    fun getNightlyReflectionByDate(date: String): Flow<NightlyReflection?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNightlyReflection(reflection: NightlyReflection)
}
