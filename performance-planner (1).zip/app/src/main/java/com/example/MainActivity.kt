package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.testTag
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.Screen
import com.example.ui.navigation.mainScreensList
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PlannerViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: PlannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val isLoggedIn by viewModel.isLoggedIn.collectAsState()

                if (!isLoggedIn) {
                    LoginScreen(
                        viewModel = viewModel,
                        onLoginSuccess = {}
                    )
                } else {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.AxisDashboard.route

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            NavigationBar(
                                modifier = Modifier.testTag("main_navigation_bar"),
                                containerColor = Color.White, // Lighter, clean white-first theme
                                tonalElevation = 3.dp
                            ) {
                                mainScreensList.forEach { screen ->
                                    val isSelected = currentRoute == screen.route
                                    val isAxis = screen == Screen.AxisDashboard

                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = {
                                            if (currentRoute != screen.route) {
                                                navController.navigate(screen.route) {
                                                    // Pop up to the start destination of the graph to
                                                    // avoid building up a large stack of destinations
                                                    popUpTo(Screen.AxisDashboard.route) {
                                                        saveState = true
                                                    }
                                                    // Avoid multiple copies of the same destination when
                                                    // reselecting the same item
                                                    launchSingleTop = true
                                                    // Restore state when reselecting a previously selected item
                                                    restoreState = true
                                                }
                                            }
                                        },
                                        icon = {
                                            if (isAxis) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(52.dp)
                                                        .clip(RoundedCornerShape(16.dp))
                                                        .background(
                                                            if (isSelected) MaterialTheme.colorScheme.secondary // Royal Business Blue
                                                            else MaterialTheme.colorScheme.primary // Deep Indigo/Slate
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (isSelected) screen.activeIcon else screen.inactiveIcon,
                                                        contentDescription = screen.title,
                                                        tint = Color.White, // Always fully visible
                                                        modifier = Modifier.size(28.dp)
                                                    )
                                                }
                                            } else {
                                                Icon(
                                                    imageVector = if (isSelected) screen.activeIcon else screen.inactiveIcon,
                                                    contentDescription = screen.title,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        },
                                        label = {
                                            Text(
                                                text = screen.title,
                                                style = if (isAxis) {
                                                    MaterialTheme.typography.labelSmall.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                                                    )
                                                } else {
                                                    MaterialTheme.typography.labelSmall.copy(
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            )
                                        },
                                        modifier = Modifier.testTag("nav_item_${screen.route}"),
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = MaterialTheme.colorScheme.secondary,
                                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                            selectedTextColor = MaterialTheme.colorScheme.secondary,
                                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                            indicatorColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)
                                        ),
                                        alwaysShowLabel = true
                                    )
                                }
                            }
                        },
                        contentWindowInsets = WindowInsets.safeDrawing
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = Screen.AxisDashboard.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(Screen.Today.route) {
                                TodayScreen(viewModel = viewModel)
                            }
                            composable(Screen.Planner.route) {
                                PlannerScreen(viewModel = viewModel)
                            }
                            composable(Screen.AxisDashboard.route) {
                                AxisDashboardScreen(viewModel = viewModel)
                            }
                            composable(Screen.Review.route) {
                                ReviewScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
