package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val activeIcon: ImageVector, val inactiveIcon: ImageVector) {
    object Today : Screen("today", "Today", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle)
    object Planner : Screen("planner", "Planner", Icons.Filled.DateRange, Icons.Outlined.DateRange)
    object AxisDashboard : Screen("axis_dashboard", "AXIS", Icons.Filled.MyLocation, Icons.Outlined.MyLocation)
    object Review : Screen("review", "Review", Icons.Filled.RateReview, Icons.Outlined.RateReview)
    object Login : Screen("login", "Login", Icons.Filled.Lock, Icons.Outlined.Lock)
}

val mainScreensList = listOf(
    Screen.Today,
    Screen.Planner,
    Screen.AxisDashboard,
    Screen.Review
)
