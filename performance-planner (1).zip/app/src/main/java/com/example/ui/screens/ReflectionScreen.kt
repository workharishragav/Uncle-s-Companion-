package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.NightlyReflection
import com.example.viewmodel.PlannerViewModel

@Composable
fun ReflectionScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val date by viewModel.selectedDate.collectAsState()
    val reflectionVal by viewModel.nightlyReflection.collectAsState()

    var planVsActual by remember { mutableStateOf("") }
    var didVictoryHour by remember { mutableStateOf(false) }
    var didSavers by remember { mutableStateOf(false) }
    var rating by remember { mutableStateOf(5f) }
    var expensesLogged by remember { mutableStateOf(false) }
    var portfolioChecked by remember { mutableStateOf(false) }
    var extraNotes by remember { mutableStateOf("") }

    // Synchronize local UI state whenever the database entry updates or date changes
    LaunchedEffect(reflectionVal, date) {
        if (reflectionVal != null) {
            planVsActual = reflectionVal!!.planVsActual
            didVictoryHour = reflectionVal!!.didVictoryHour
            didSavers = reflectionVal!!.didSavers
            rating = reflectionVal!!.rating.toFloat()
            expensesLogged = reflectionVal!!.expensesLogged
            portfolioChecked = reflectionVal!!.portfolioChecked
            extraNotes = reflectionVal!!.notes
        } else {
            planVsActual = ""
            didVictoryHour = false
            didSavers = false
            rating = 5f
            expensesLogged = false
            portfolioChecked = false
            extraNotes = ""
        }
    }

    Scaffold(
        modifier = modifier.testTag("reflection_screen"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Column {
                    Text(
                        text = "Nightly Deconstruction Flow",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Deep debrief for date: $date",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary)
                    )
                }
            }

            // Quick tips from the PDF on Debriefing
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "💡 Peak Strategy: Planning & sequencing tasks increases focus and executive productivity by up to 10x.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onTertiaryContainer)
                        )
                    }
                }
            }

            // Section 1: Completion Indicators
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Habit & Integrity Confirmations",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("5:00 AM Victory Hour met?", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = didVictoryHour,
                                onCheckedChange = { didVictoryHour = it },
                                modifier = Modifier.testTag("victory_hour_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Morning S.A.V.E.R.S routines?", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = didSavers,
                                onCheckedChange = { didSavers = it },
                                modifier = Modifier.testTag("savers_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Portfolio Check (Groww/Zerodha/Zebpay)?", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = portfolioChecked,
                                onCheckedChange = { portfolioChecked = it },
                                modifier = Modifier.testTag("portfolio_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Logged Daily Expenses?", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = expensesLogged,
                                onCheckedChange = { expensesLogged = it },
                                modifier = Modifier.testTag("expenses_switch")
                            )
                        }
                    }
                }
            }

            // Section 2: Integrity Rating
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Integrity Day Rating",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${rating.toInt()} / 10",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "How effectively did you block distractions and execute your top priorities?",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Slider(
                            value = rating,
                            onValueChange = { rating = it },
                            valueRange = 1f..10f,
                            steps = 8,
                            modifier = Modifier.testTag("rating_slider")
                        )
                    }
                }
            }

            // Section 3: Text Journaling
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Plan vs. Actual Debrief",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Deconstruct bottlenecks, distraction zones, or wins that occurred today.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = planVsActual,
                            onValueChange = { planVsActual = it },
                            placeholder = { Text("What went well? What didn't go as planned? Any lessons learned?") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("plan_vs_actual_input"),
                            maxLines = 8
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Strategic Insights & Ideas",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = extraNotes,
                            onValueChange = { extraNotes = it },
                            placeholder = { Text("Ideas for tomorrow, team improvements, setup parameters...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            maxLines = 5
                        )
                    }
                }
            }

            // Save Actions Panel
            item {
                Button(
                    onClick = {
                        viewModel.saveNightlyReflection(
                            planVsActual = planVsActual,
                            didVictoryHour = didVictoryHour,
                            didSavers = didSavers,
                            rating = rating.toInt(),
                            expensesLogged = expensesLogged,
                            portfolioChecked = portfolioChecked,
                            notes = extraNotes
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_reflection_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Performance Debrief")
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
