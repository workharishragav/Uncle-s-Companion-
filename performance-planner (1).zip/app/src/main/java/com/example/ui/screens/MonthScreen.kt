package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import java.text.DateFormatSymbols
import java.util.Calendar
import com.example.data.model.MonthlyGoal
import com.example.data.model.Task
import com.example.viewmodel.PlannerViewModel

@Composable
fun MonthScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val monthlyGoalsVal by viewModel.monthlyGoals.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val currentMonth by viewModel.currentMonth.collectAsState()
    val currentYear by viewModel.currentYear.collectAsState()

    var showAddGoalDialog by remember { mutableStateOf(false) }

    // Date/Calendar helper
    val monthName = remember(currentMonth) {
        DateFormatSymbols().months[currentMonth - 1]
    }

    val daysInMonth = remember(currentMonth, currentYear) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, currentYear)
        cal.set(Calendar.MONTH, currentMonth - 1)
        cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    val firstDayOfWeek = remember(currentMonth, currentYear) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, currentYear)
        cal.set(Calendar.MONTH, currentMonth - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        // Adjust Sunday = 1 to Monday = 2
        val day = cal.get(Calendar.DAY_OF_WEEK)
        if (day == Calendar.SUNDAY) 7 else day - 1
    }

    // Filters corresponding to Month View from Sheet 3
    val importantDates = remember(allTasks) {
        allTasks.filter { it.category == "ImportantDate" }
    }
    val generalMonthlyTodo = remember(allTasks) {
        allTasks.filter { it.category == "MonthlyTodo" }
    }
    val monthNotes = remember(allTasks) {
        allTasks.find { it.category == "MonthlyNotes" }?.title ?: ""
    }

    var isAddingImportantDate by remember { mutableStateOf(false) }
    var isAddingMonthlyTodo by remember { mutableStateOf(false) }
    var isEditingNotes by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.testTag("month_screen"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Month Selector Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Monthly Blueprint",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "$monthName $currentYear",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary)
                        )
                    }

                    Row {
                        IconButton(onClick = {
                            if (viewModel.currentMonth.value == 1) {
                                viewModel.currentMonth.value = 12
                                viewModel.currentYear.value -= 1
                            } else {
                                viewModel.currentMonth.value -= 1
                            }
                        }) {
                            Icon(Icons.Default.ChevronLeft, "Previous Month")
                        }
                        IconButton(onClick = {
                            if (viewModel.currentMonth.value == 12) {
                                viewModel.currentMonth.value = 1
                                viewModel.currentYear.value += 1
                            } else {
                                viewModel.currentMonth.value += 1
                            }
                        }) {
                            Icon(Icons.Default.ChevronRight, "Next Month")
                        }
                    }
                }
            }

            // Month Grid Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Calendar Horizon",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Grid headers MON-SUN
                        Row(modifier = Modifier.fillMaxWidth()) {
                            listOf("M", "T", "W", "T", "F", "S", "S").forEach { day ->
                                Text(
                                    text = day,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Days layout
                        var dayCounter = 1
                        val totalCellsNeeded = 42 // 6 rows max
                        val rowsCount = if (daysInMonth + firstDayOfWeek - 1 > 35) 6 else 5

                        for (r in 0 until rowsCount) {
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                for (c in 1..7) {
                                    val cellIndex = r * 7 + c
                                    val isDayCell = cellIndex >= firstDayOfWeek && dayCounter <= daysInMonth
                                    val dayNumToWrite = dayCounter

                                    if (isDayCell) {
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .padding(2.dp)
                                                .background(
                                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                                                    MaterialTheme.shapes.extraSmall
                                                )
                                                .clickable {
                                                    // Move selected date string to this clicked date
                                                    val formattedDay = String.format("%02d", dayNumToWrite)
                                                    val formattedMonth = String.format("%02d", currentMonth)
                                                    viewModel.changeSelectedDate("$currentYear-$formattedMonth-$formattedDay")
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = dayNumToWrite.toString(),
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                        }
                                        dayCounter++
                                    } else {
                                        Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 1: Monthly Goals (Top 5)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrackChanges, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Monthly Strategic Goals (Top 5)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            if (monthlyGoalsVal.size < 5) {
                                Button(
                                    onClick = { showAddGoalDialog = true },
                                    modifier = Modifier.testTag("add_monthly_goal")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Goal", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        if (monthlyGoalsVal.isEmpty()) {
                            Text(
                                text = "Define up to 5 strategic anchors of progress for this month.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        } else {
                            monthlyGoalsVal.forEach { goal ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.toggleMonthlyGoal(goal) }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (goal.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = null,
                                            tint = if (goal.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "${goal.goalNumber}. ${goal.content}",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                textDecoration = if (goal.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                                color = if (goal.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                    }
                                    IconButton(onClick = { viewModel.deleteMonthlyGoal(goal.id) }) {
                                        Icon(Icons.Default.Delete, "Delete Goal", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: Important Dates & Monthly Todo Side-by-Side (or stacked columns for compact view)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Important Dates Block
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Important Dates & Reviews",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                IconButton(onClick = { isAddingImportantDate = true }) {
                                    Icon(Icons.Default.Add, "Add Date")
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            if (importantDates.isEmpty()) {
                                Text(
                                    text = "No key dates logged.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                                )
                            } else {
                                importantDates.forEach { task ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f).clickable { viewModel.toggleTask(task) },
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (task.isCompleted) Icons.Default.Check else Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = if (task.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                                )
                                            )
                                        }
                                        IconButton(onClick = { viewModel.deleteTask(task.id) }, modifier = Modifier.size(32.dp)) {
                                            Icon(Icons.Default.Clear, "Delete", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Monthly Todo Block
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Task, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Monthly Master To-Do",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                IconButton(onClick = { isAddingMonthlyTodo = true }) {
                                    Icon(Icons.Default.Add, "Add To-Do")
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            if (generalMonthlyTodo.isEmpty()) {
                                Text(
                                    text = "Master to-do backlog is empty.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                                )
                            } else {
                                generalMonthlyTodo.forEach { task ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f).clickable { viewModel.toggleTask(task) },
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (task.isCompleted) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                                )
                                            )
                                        }
                                        IconButton(onClick = { viewModel.deleteTask(task.id) }, modifier = Modifier.size(32.dp)) {
                                            Icon(Icons.Default.Clear, "Delete", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 3: Notes & Strategies
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Notes, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Monthly Notes & Core Operational Strategies",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            IconButton(onClick = { isEditingNotes = true }) {
                                Icon(Icons.Default.Edit, "Edit Notes")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        if (monthNotes.isEmpty()) {
                            Text(
                                text = "Empty strategic log. Log system setups, team improvements, and compliance items here.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                            )
                        } else {
                            Text(
                                text = monthNotes,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Add Goal Dialog
    if (showAddGoalDialog) {
        var goalText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddGoalDialog = false },
            title = { Text("Add Monthly Strategic Anchor Goal") },
            text = {
                OutlinedTextField(
                    value = goalText,
                    onValueChange = { goalText = it },
                    placeholder = { Text("Describe goal...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (goalText.isNotBlank()) {
                            viewModel.addMonthlyGoal(goalText, monthlyGoalsVal.size + 1)
                            showAddGoalDialog = false
                        }
                    },
                    enabled = goalText.isNotBlank()
                ) {
                    Text("Save Goal")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddGoalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Important Date Dialog
    if (isAddingImportantDate) {
        var textVal by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { isAddingImportantDate = false },
            title = { Text("Log Important Date / Review Event") },
            text = {
                OutlinedTextField(
                    value = textVal,
                    onValueChange = { textVal = it },
                    placeholder = { Text("Review, Release, Audit deadline, etc.") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textVal.isNotBlank()) {
                            viewModel.addTask(textVal, "ImportantDate", "A")
                            isAddingImportantDate = false
                        }
                    },
                    enabled = textVal.isNotBlank()
                ) {
                    Text("Log Event")
                }
            },
            dismissButton = {
                TextButton(onClick = { isAddingImportantDate = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Monthly Todo Item
    if (isAddingMonthlyTodo) {
        var textVal by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { isAddingMonthlyTodo = false },
            title = { Text("Log Master To-Do Action") },
            text = {
                OutlinedTextField(
                    value = textVal,
                    onValueChange = { textVal = it },
                    placeholder = { Text("Enter operational task...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textVal.isNotBlank()) {
                            viewModel.addTask(textVal, "MonthlyTodo", "B")
                            isAddingMonthlyTodo = false
                        }
                    },
                    enabled = textVal.isNotBlank()
                ) {
                    Text("Save To-Do")
                }
            },
            dismissButton = {
                TextButton(onClick = { isAddingMonthlyTodo = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Notes Dialog
    if (isEditingNotes) {
        var textVal by remember { mutableStateOf(monthNotes) }
        AlertDialog(
            onDismissRequest = { isEditingNotes = false },
            title = { Text("Edit Monthly Operational Strategies & Notes") },
            text = {
                OutlinedTextField(
                    value = textVal,
                    onValueChange = { textVal = it },
                    placeholder = { Text("Write strategy comments, meeting details, setups...") },
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    maxLines = 10
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        // Delete previous notes if exists
                        val previousNotesTask = allTasks.find { it.category == "MonthlyNotes" }
                        if (previousNotesTask != null) {
                            viewModel.deleteTask(previousNotesTask.id)
                        }
                        if (textVal.isNotBlank()) {
                            viewModel.addTask(textVal, "MonthlyNotes", "C")
                        }
                        isEditingNotes = false
                    }
                ) {
                    Text("Update Notes")
                }
            },
            dismissButton = {
                TextButton(onClick = { isEditingNotes = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
