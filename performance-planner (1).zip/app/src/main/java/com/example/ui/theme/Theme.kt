package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val AxisColorScheme =
  lightColorScheme(
    primary = AxisPrimary,
    secondary = AxisSecondary,
    tertiary = AxisTertiary,
    background = AxisBackground,
    surface = AxisSurface,
    surfaceVariant = AxisSurfaceVariant,
    onBackground = AxisOnBackground,
    onSurface = AxisOnSurface,
    outline = AxisOutline,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onSurfaceVariant = AxisOnSurface
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false, // Force white-first theme for AXIS corporate look
  dynamicColor: Boolean = false, // Disable dynamic colors to enforce AXIS premium palette
  content: @Composable () -> Unit,
) {
  val colorScheme = AxisColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

