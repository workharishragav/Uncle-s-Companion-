package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.RpmPillar
import com.example.viewmodel.PlannerViewModel

@Composable
fun RpmScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val pillars by viewModel.rpmPillars.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()

    var showAddPillarDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.testTag("rpm_screen"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddPillarDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_rpm_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add RPM Topic")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Column {
                    Text(
                        text = "Results-Purpose-Map (RPM)",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Align execution directly with meaning. Define the Result and Purpose before formulating actions.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                    )
                }
            }

            if (pillars.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.Explore,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Strategic Purpose Pillar Map",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Create RPM topics (e.g. Plant Operations, Financial FY26-27) defining the Target Result & Core Purpose.",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(pillars) { pillar ->
                    RpmPillarCard(
                        pillar = pillar,
                        linkedTasks = allTasks.filter { it.rpmPillarId == pillar.id },
                        onToggleTask = { viewModel.toggleTask(it) },
                        onDeletePillar = { viewModel.deleteRpmPillar(pillar.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    if (showAddPillarDialog) {
        AddRpmPillarDialog(
            onDismiss = { showAddPillarDialog = false },
            onSave = { topic, category, result, purpose, priority, duration ->
                viewModel.addRpmPillar(
                    RpmPillar(
                        topic = topic,
                        category = category,
                        result = result,
                        purpose = purpose,
                        priority = priority,
                        duration = duration
                    )
                )
                showAddPillarDialog = false
            }
        )
    }
}

@Composable
fun RpmPillarCard(
    pillar: RpmPillar,
    linkedTasks: List<com.example.data.model.Task>,
    onToggleTask: (com.example.data.model.Task) -> Unit,
    onDeletePillar: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = pillar.topic,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    Text(
                        text = "Category: ${pillar.category}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    SuggestionChip(
                        onClick = { },
                        label = { Text("Priority ${pillar.priority}") },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    IconButton(onClick = onDeletePillar) {
                        Icon(Icons.Default.Delete, "Delete Topic", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            // Desired Result Box
            Text(
                text = "🎯 DESIRED RESULT / OUTCOME",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
            )
            Text(
                text = pillar.result,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            // Dynamic Core Purpose
            Text(
                text = "⚡ CORE PURPOSE",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
            )
            Text(
                text = pillar.purpose,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            if (pillar.duration.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 12.dp)) {
                    Icon(
                        Icons.Default.Speed,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Target Duration: ${pillar.duration}", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))
                }
            }

            // Linked Action Plans (The Map segment of RPM)
            Text(
                text = "📜 ALIGNED ACTION PLANS (${linkedTasks.size})",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )

            if (linkedTasks.isEmpty()) {
                Text(
                    text = "No action activities linked. Create a task in Today screen and map it to this Topic to build your Massive Action Plan.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.padding(top = 4.dp)
                )
            } else {
                Column(modifier = Modifier.padding(top = 4.dp)) {
                    linkedTasks.forEach { task ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleTask(task) }
                                .padding(vertical = 4.dp, horizontal = 4.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (task.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                    color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                                ),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRpmPillarDialog(
    onDismiss: () -> Unit,
    onSave: (topic: String, category: String, result: String, purpose: String, priority: String, duration: String) -> Unit
) {
    var topic by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Plant Operations") }
    var result by remember { mutableStateOf("") }
    var purpose by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("High") }
    var duration by remember { mutableStateOf("") }

    val categories = listOf("Plant Operations", "Ensinger Culture", "Team Setup", "Team Development", "Financial FY26-27")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    if (topic.isNotBlank() && result.isNotBlank() && purpose.isNotBlank()) {
                        onSave(topic, selectedCategory, result, purpose, priority, duration)
                    }
                },
                enabled = topic.isNotBlank() && result.isNotBlank() && purpose.isNotBlank(),
                modifier = Modifier.testTag("save_rpm")
            ) {
                Text("Map & Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        title = {
            Text(
                text = "Formulate Strategic Topic (RPM)",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic Theme / Action Plan Subject") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rpm_subject_input")
                    )
                }

                item {
                    Text("Pillar Business Category:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    Column {
                        categories.forEach { cat ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedCategory = cat }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedCategory == cat, onClick = { selectedCategory = cat })
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(cat, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = result,
                        onValueChange = { result = it },
                        label = { Text("🎯 Desired Result / Clear Outcome") },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        maxLines = 3
                    )
                }

                item {
                    OutlinedTextField(
                        value = purpose,
                        onValueChange = { purpose = it },
                        label = { Text("⚡ Core Purpose (Why do you want this?)") },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        maxLines = 3
                    )
                }

                item {
                    Text("Priority Level:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("High", "Medium", "Low").forEach { p ->
                            FilterChip(
                                selected = priority == p,
                                onClick = { priority = p },
                                label = { Text(p) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = duration,
                        onValueChange = { duration = it },
                        label = { Text("Duration estimate (e.g., Q1, 6 Weeks, 2 Hours)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    )
}
