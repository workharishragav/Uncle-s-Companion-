package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import com.example.data.model.RoutineActivity
import com.example.data.model.Task
import com.example.viewmodel.PlannerViewModel

@Composable
fun TodayScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val date by viewModel.selectedDate.collectAsState()
    val routines by viewModel.dailyRoutines.collectAsState()
    val tasks by viewModel.allTasks.collectAsState()
    val rpmPillars by viewModel.rpmPillars.collectAsState()

    var showAddTaskDialog by remember { mutableStateOf(false) }

    // Filter tasks specifically for current date
    val todayTasks = remember(tasks, date) {
        tasks.filter { task ->
            if (task.associatedDay != null) {
                false
            } else {
                val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val taskDateStr = format.format(Date(task.targetDate))
                taskDateStr == date
            }
        }
    }

    val highPriorityTasks = remember(todayTasks) {
        todayTasks.filter { it.priority == "A" }.take(3)
    }

    val regularTasks = remember(todayTasks) {
        todayTasks.filter { it.priority != "A" }
    }

    // Statistics: Completed Tasks / Total Tasks
    val totalTasksCount = todayTasks.size
    val completedTasksCount = todayTasks.count { it.isCompleted }

    val routineProgress = remember(routines) {
        val total = routines.size
        val completed = routines.count { it.isCompleted }
        if (total > 0) completed.toFloat() / total else 0f
    }

    val saversCompleted = remember(routines) {
        routines.find { it.blockName.contains("S.A.V.E.R.S", ignoreCase = true) }?.isCompleted ?: false
    }
    val victoryCompleted = remember(routines) {
        routines.find { it.blockName.contains("Victory Hour", ignoreCase = true) }?.isCompleted ?: false
    }

    var ticks by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(15000) // check every 15 seconds
            ticks++
        }
    }
    val activeBlockString = remember(routines, ticks) {
        getCurrentActiveTimeBlock(routines)
    }

    Scaffold(
        modifier = modifier.testTag("today_screen"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddTaskDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_task_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Today Task")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Sleek Chrono Controller
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.selectPreviousDay() },
                        modifier = Modifier.testTag("prev_day_button")
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Day", tint = MaterialTheme.colorScheme.primary)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = date,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            ),
                            modifier = Modifier.testTag("selected_date_text")
                        )
                        Text(
                            text = "Today's Performance Canvas",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.selectNextDay() },
                        modifier = Modifier.testTag("next_day_button")
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Day", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Habit integrity indicators (Victory hour & S.A.V.E.R.S)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    HabitMetricChip(
                        label = "Victory Hour (5 AM)",
                        isMet = victoryCompleted,
                        icon = Icons.Default.WbSunny,
                        tag = "victory_hour_chip"
                    )
                    HabitMetricChip(
                        label = "S.A.V.E.R.S Habit",
                        isMet = saversCompleted,
                        icon = Icons.Default.AutoAwesome,
                        tag = "savers_chip"
                    )
                }
            }

            // 2. Main Cascade (Scrollable)
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Sub-Item 1: Daily Progress & Active Focus Time Block
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Daily Progress Section
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Daily Progress",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                Text(
                                    text = "$completedTasksCount / $totalTasksCount Tasks Completed",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            val progressFloat = if (totalTasksCount > 0) completedTasksCount.toFloat() / totalTasksCount else 0f
                            LinearProgressIndicator(
                                progress = { progressFloat },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Current Active Time Block Section
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f))
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.AccessTime,
                                    contentDescription = "Active Block",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Current Active Time Block",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                    Text(
                                        text = activeBlockString,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Sub-Item 2: Top 3 High-Value Priorities (A Priority)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Top 3 High Value Priorities",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            if (highPriorityTasks.isEmpty()) {
                                Text(
                                    text = "No top-priority items set. Tap + to add high-value targets (Priority A).",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                highPriorityTasks.forEach { task ->
                                    TaskItemRow(
                                        task = task,
                                        onToggle = { viewModel.toggleTask(task) },
                                        onDelete = { viewModel.deleteTask(task.id) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Sub-Item 3: Daily Routine Checklist
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.ListAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Daily Routine Checklist",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            if (routines.isEmpty()) {
                                Text(
                                    text = "No routines scheduled.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            } else {
                                routines.forEach { activity ->
                                    RoutineItemRow(
                                        activity = activity,
                                        onToggle = { viewModel.toggleRoutineActivity(activity) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Sub-Item 4: General Operational Tasks
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Assignment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "General Operational Tasks",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            if (regularTasks.isEmpty()) {
                                Text(
                                    text = "All clear! Safe and steady.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                regularTasks.forEach { task ->
                                    TaskItemRow(
                                        task = task,
                                        onToggle = { viewModel.toggleTask(task) },
                                        onDelete = { viewModel.deleteTask(task.id) }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }

    // Task Add Dialog
    if (showAddTaskDialog) {
        AddTaskDialog(
            rpmPillars = rpmPillars,
            onDismiss = { showAddTaskDialog = false },
            onAdd = { title, priority, category, pillarId, duration ->
                viewModel.addTask(title, category, priority, null, pillarId, duration)
                showAddTaskDialog = false
            }
        )
    }
}

// Time parsing utility and active block extractor helpers
private fun getCurrentActiveTimeBlock(routines: List<RoutineActivity>): String {
    if (routines.isEmpty()) return "Refocus Phase: Execute priorities"
    val now = Calendar.getInstance()
    val hour24 = now.get(Calendar.HOUR_OF_DAY)
    val minute = now.get(Calendar.MINUTE)
    val currentMinutesSinceMidnight = hour24 * 60 + minute

    for (routine in routines) {
        try {
            val name = routine.blockName
            val parts = name.split(": ")
            if (parts.isNotEmpty()) {
                val timePartString = parts[0]
                val timeRange = timePartString.split(" - ")
                if (timeRange.size == 2) {
                    val startMin = parseTimeToMinutes(timeRange[0].trim())
                    val endMin = parseTimeToMinutes(timeRange[1].trim())
                    if (startMin != null && endMin != null) {
                        if (currentMinutesSinceMidnight in startMin..endMin) {
                            return name
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // keep looking
        }
    }

    return when {
        hour24 in 5..7 -> "05:00 AM - 05:50 AM: S.A.V.E.R.S Routine"
        hour24 in 8..9 -> "09:00 AM - 09:30 AM: Traffic University"
        hour24 in 10..11 -> "09:30 AM - 11:00 AM: Focus 90/90/1 Rule (Bubble Focus)"
        hour24 in 12..13 -> "11:00 AM - 01:00 PM: Focus 60/10 Rule"
        hour24 in 14..15 -> "02:00 PM - 04:00 PM: Focus 60/10 (Meetings & Flow)"
        hour24 in 16..17 -> "04:00 PM - 06:00 PM: 5 PM Next Day Planning"
        hour24 in 18..21 -> "07:30 PM - 09:30 PM: Offline, Connections & Recovery"
        else -> "09:30 PM - 10:00 PM: Nightly Journal Debrief & Performance Review"
    }
}

private fun parseTimeToMinutes(timeStr: String): Int? {
    return try {
        val normalized = timeStr.trim()
        val parts = normalized.split(" ")
        if (parts.size != 2) return null
        val timeParts = parts[0].split(":")
        if (timeParts.size != 2) return null
        var hour = timeParts[0].toInt()
        val min = timeParts[1].toInt()
        val amPm = parts[1].uppercase()
        if (amPm == "PM" && hour < 12) hour += 12
        if (amPm == "AM" && hour == 12) hour = 0
        hour * 60 + min
    } catch (e: Exception) {
        null
    }
}

@Composable
fun HabitMetricChip(
    label: String,
    isMet: Boolean,
    icon: ImageVector,
    tag: String
) {
    val chipColor = if (isMet) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    val contentColor = if (isMet) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .testTag(tag)
            .clip(RoundedCornerShape(8.dp))
            .background(chipColor)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = if (isMet) MaterialTheme.colorScheme.primary else contentColor
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = contentColor)
        )
    }
}

@Composable
fun RoutineItemRow(
    activity: RoutineActivity,
    onToggle: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("routine_item_${activity.id}")
            .clickable(onClick = onToggle)
            .padding(vertical = 8.dp)
    ) {
        Checkbox(
            checked = activity.isCompleted,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(
                checkedColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.testTag("routine_checkbox_${activity.id}")
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = activity.blockName,
            style = MaterialTheme.typography.bodyMedium.copy(
                textDecoration = if (activity.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                color = if (activity.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (activity.type == "HABIT") FontWeight.Medium else FontWeight.Normal
            )
        )
    }
}

@Composable
fun TaskItemRow(
    task: Task,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}")
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onToggle)
        ) {
            Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = if (task.priority == "A") MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.testTag("task_checkbox_${task.id}")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                        color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (task.priority == "A") FontWeight.Bold else FontWeight.Normal
                    )
                )
                if (task.duration.isNotEmpty() || task.category != "General") {
                    Text(
                        text = listOfNotNull(
                            if (task.category != "General") task.category else null,
                            if (task.duration.isNotEmpty()) "⌛ ${task.duration}" else null
                        ).joinToString(" | "),
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                    )
                }
            }
        }

        IconButton(
            onClick = onDelete,
            modifier = Modifier.testTag("delete_task_${task.id}")
        ) {
            Icon(
                Icons.Default.Delete,
                contentDescription = "Delete Task",
                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(
    rpmPillars: List<com.example.data.model.RpmPillar>,
    onDismiss: () -> Unit,
    onAdd: (title: String, priority: String, category: String, pillarId: Int?, duration: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf("B") }
    var selectedDuration by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("General") }
    var selectedPillarId by remember { mutableStateOf<Int?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("add_task_dialog")
        ) {
            Column(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Log Action Plan Item",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Plan") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_input_field")
                )

                // Priority Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Priority: ", style = MaterialTheme.typography.bodyMedium)
                    listOf("A" to "Top (A)", "B" to "Medium (B)", "C" to "Low (C)").forEach { (key, name) ->
                        FilterChip(
                            selected = selectedPriority == key,
                            onClick = { selectedPriority = key },
                            label = { Text(name) },
                            modifier = Modifier.testTag("priority_chip_$key")
                        )
                    }
                }

                // Duration Estimated Input
                OutlinedTextField(
                    value = selectedDuration,
                    onValueChange = { selectedDuration = it },
                    label = { Text("Estimated Duration (e.g. 30min, 1.5h)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Link To RPM Pillar Selection
                if (rpmPillars.isNotEmpty()) {
                    Text("Link to strategic RPM Topic:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .padding(4.dp)
                    ) {
                        items(rpmPillars) { pillar ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPillarId = if (selectedPillarId == pillar.id) null else pillar.id
                                        if (selectedPillarId != null) {
                                            selectedCategory = pillar.category
                                        }
                                    }
                                    .padding(vertical = 6.dp, horizontal = 8.dp)
                                    .background(
                                        if (selectedPillarId == pillar.id) MaterialTheme.colorScheme.secondaryContainer
                                        else Color.Transparent,
                                        RoundedCornerShape(4.dp)
                                    ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPillarId == pillar.id,
                                    onClick = {
                                        selectedPillarId = if (selectedPillarId == pillar.id) null else pillar.id
                                        if (selectedPillarId != null) {
                                            selectedCategory = pillar.category
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = pillar.topic,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.testTag("dialog_cancel")) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAdd(title, selectedPriority, selectedCategory, selectedPillarId, selectedDuration)
                            }
                        },
                        enabled = title.isNotBlank(),
                        modifier = Modifier.testTag("dialog_confirm")
                    ) {
                        Text("Add")
                    }
                }
            }
        }
    }
}
