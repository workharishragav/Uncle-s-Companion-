package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoutineActivity
import com.example.viewmodel.PlannerViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AxisDashboardScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val date by viewModel.selectedDate.collectAsState()
    val routines by viewModel.dailyRoutines.collectAsState()
    val tasks by viewModel.allTasks.collectAsState()
    val weeklyGoals by viewModel.weeklyGoals.collectAsState()
    val monthlyGoals by viewModel.monthlyGoals.collectAsState()
    val loginType by viewModel.loginType.collectAsState()

    var showQuickTaskDialog by remember { mutableStateOf(false) }
    var showGuideDialog by remember { mutableStateOf(false) }

    // Aggregate Stats
    val todayTasks = remember(tasks, date) {
        tasks.filter { task ->
            if (task.associatedDay != null) {
                false
            } else {
                val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val taskDateStr = format.format(Date(task.targetDate))
                taskDateStr == date
            }
        }
    }

    val completedTasksCount = todayTasks.count { it.isCompleted }
    val totalTasksCount = todayTasks.size

    val completedRoutines = routines.count { it.isCompleted }
    val totalRoutines = routines.size

    var ticks by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(15000)
            ticks++
        }
    }

    val activeBlock = remember(routines, ticks) {
        getCurrentActiveBlockFromRoutines(routines)
    }

    Scaffold(
        modifier = modifier.testTag("axis_dashboard_screen"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = "Axis",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AXIS EXECUTIVE DASHBOARD",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.5.sp
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showGuideDialog = true },
                        modifier = Modifier.testTag("action_guide_button")
                    ) {
                        Icon(Icons.Default.HelpOutline, contentDescription = "System Guidebook")
                    }
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("action_logout_button")
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showQuickTaskDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Priority Target") },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("dashboard_add_target_fab")
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Beautiful User Welcome Banner
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("welcome_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (loginType.isNotEmpty()) loginType.take(1).uppercase() else "D",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Welcome back, Exec-Operator ($loginType)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Data sync verified & fully offline-secured.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.secondary)
                            )
                        }
                    }
                    
                }
            }

            // Today's Live Active Time Block focus
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("active_focus_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CURRENT OPERATIONS FOCUS",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = activeBlock,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Date Target: $date",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Text(
                                text = "Level: HIGH PRIORITY",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            )
                        }
                    }
                }
            }

            // Visual Progress Matrices
            item {
                Text(
                    text = "PERFORMANCE OVERVIEW MATRICES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            item {
                // Horizontal scroll or vertical cards for progress trackers
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Task Execution
                    ProgressMetricsRow(
                        title = "Priority Task Executions",
                        done = completedTasksCount,
                        total = totalTasksCount,
                        percentage = if (totalTasksCount > 0) completedTasksCount.toFloat() / totalTasksCount else 0f,
                        color = MaterialTheme.colorScheme.primary,
                        tag = "tasks_matrix"
                    )

                    // Habits Integrity
                    ProgressMetricsRow(
                        title = "Routine Blocks Checklist",
                        done = completedRoutines,
                        total = totalRoutines,
                        percentage = if (totalRoutines > 0) completedRoutines.toFloat() / totalRoutines else 0f,
                        color = MaterialTheme.colorScheme.secondary,
                        tag = "routines_matrix"
                    )

                    val completedWeekly = weeklyGoals.count { it.isCompleted }
                    val totalWeekly = weeklyGoals.size
                    // Weekly Planning Focus
                    ProgressMetricsRow(
                        title = "Weekly Core Milestones",
                        done = completedWeekly,
                        total = totalWeekly,
                        percentage = if (totalWeekly > 0) completedWeekly.toFloat() / totalWeekly else 0f,
                        color = MaterialTheme.colorScheme.tertiary,
                        tag = "weekly_matrix"
                    )
                }
            }

            // Quick Actions Panel
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("quick_actions_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = CardDefaults.outlinedCardBorder(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "QUICK CONTROL PANEL",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showQuickTaskDialog = true },
                                modifier = Modifier.weight(1f).testTag("quick_add_task_btn"),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Icon(Icons.Default.AddTask, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("New Target", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { showGuideDialog = true },
                                modifier = Modifier.weight(1f).testTag("quick_guide_btn"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Guidebook", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // New Priority Target Add Dialog
    if (showQuickTaskDialog) {
        var taskTitle by remember { mutableStateOf("") }
        var isHighPriority by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showQuickTaskDialog = false },
            title = { Text("Deploy New Target Objective", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("Objective Title") },
                        modifier = Modifier.fillMaxWidth().testTag("quick_task_title_input"),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isHighPriority,
                            onCheckedChange = { isHighPriority = it },
                            modifier = Modifier.testTag("quick_task_priority_checkbox")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mark as High-Value Priority (Level-A Target)",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (taskTitle.isNotBlank()) {
                            viewModel.addTask(
                                title = taskTitle,
                                priority = if (isHighPriority) "A" else "B",
                                associatedDay = null
                            )
                            showQuickTaskDialog = false
                        }
                    },
                    modifier = Modifier.testTag("quick_task_confirm_btn")
                ) {
                    Text("Deploy")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickTaskDialog = false }) {
                    Text("Cancel")
                }
            },
            modifier = Modifier.testTag("quick_task_dialog")
        )
    }

    // Elegant Guidebook Dialog
    if (showGuideDialog) {
        AlertDialog(
            onDismissRequest = { showGuideDialog = false },
            title = {
                Text("AXIS Elite Executive System Framework", fontWeight = FontWeight.Bold)
            },
            text = {
                LazyColumn(
                    modifier = Modifier.height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "Tony Robbins' RPM Framework",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Result-Purpose-Massive Action Plan: Focus strictly on Outcomes and emotional drives first instead of simple todo lists.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Text(
                            text = "Hal Elrod's S.A.V.E.R.S Method",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "Silence, Affirmations, Visualization, Exercise, Reading, Scribing. Perfect daily routine stack.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Text(
                            text = "Robin Sharma's 90/90/1 Rule",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = "For the next 90 days, devote the first 90 minutes of your workday to your #1 singular goal with zero distraction.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Text(
                            text = "System Navigation Tip",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Manage your routine blocks synchronously on the 'Today' screen. Establish weekly focus alignment on the 'Planner' screen. Reflect on actual executions inside the 'Review' screen.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showGuideDialog = false },
                    modifier = Modifier.testTag("guide_dialog_ok_btn")
                ) {
                    Text("Understood")
                }
            }
        )
    }
}

@Composable
fun ProgressMetricsRow(
    title: String,
    done: Int,
    total: Int,
    percentage: Float,
    color: androidx.compose.ui.graphics.Color,
    tag: String
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag(tag),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "$done / $total (${(percentage * 100).toInt()}%)",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { percentage },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = color,
                trackColor = color.copy(alpha = 0.15f)
            )
        }
    }
}

private fun getCurrentActiveBlockFromRoutines(routines: List<RoutineActivity>): String {
    if (routines.isEmpty()) return "Refocus Operations Stack"
    val now = Calendar.getInstance()
    val hour24 = now.get(Calendar.HOUR_OF_DAY)
    val minute = now.get(Calendar.MINUTE)
    val currentMinutesSinceMidnight = hour24 * 60 + minute

    for (routine in routines) {
        try {
            val name = routine.blockName
            val parts = name.split(": ")
            if (parts.isNotEmpty()) {
                val timePartString = parts[0]
                val timeRange = timePartString.split(" - ")
                if (timeRange.size == 2) {
                    val startMin = parseTimeToMinutes(timeRange[0].trim())
                    val endMin = parseTimeToMinutes(timeRange[1].trim())
                    if (startMin != null && endMin != null) {
                        if (currentMinutesSinceMidnight in startMin..endMin) {
                            return name
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // keep checking
        }
    }

    return "Focus 90/90/1 Elite Performance Cycle"
}

private fun parseTimeToMinutes(timeStr: String): Int? {
    return try {
        val normalized = timeStr.trim()
        val parts = normalized.split(" ")
        if (parts.size != 2) return null
        val timeParts = parts[0].split(":")
        if (timeParts.size != 2) return null
        var hour = timeParts[0].toInt()
        val min = timeParts[1].toInt()
        val amPm = parts[1].uppercase()
        if (amPm == "PM" && hour < 12) hour += 12
        if (amPm == "AM" && hour == 12) hour = 0
        hour * 60 + min
    } catch (e: Exception) {
        null
    }
}
