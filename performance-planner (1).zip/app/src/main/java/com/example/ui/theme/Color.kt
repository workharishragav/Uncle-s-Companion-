package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Elegant Slate & Gold Executive colors
val DarkBackground = Color(0xFF0F111A)
val DarkSurface = Color(0xFF161924)
val DarkSurfaceVariant = Color(0xFF1E2235)
val GoldPrimary = Color(0xFFFFB300)
val CoolSecondary = Color(0xFF14B8A6)
val RoseTertiary = Color(0xFFF43F5E)
val IceText = Color(0xFFF1F5F9)
val MutedOutline = Color(0xFF475569)

// AXIS White-First Business palette
val AxisPrimary = Color(0xFF0F172A) // Sleek Dark Slate / Deep Navy
val AxisSecondary = Color(0xFF2563EB) // Royal Business Blue
val AxisTertiary = Color(0xFF4F46E5) // Indigo Accent
val AxisBackground = Color(0xFFFFFFFF) // Pure White Background
val AxisSurface = Color(0xFFF8FAFC) // Light Slate Gray Card BG
val AxisSurfaceVariant = Color(0xFFF1F5F9) // Slate Gray Highlight / Outline Container
val AxisOnBackground = Color(0xFF0F172A) // Crisp Charcoal/Dark Slate for text
val AxisOnSurface = Color(0xFF1E293B) // Accent Dark Gray for lists or cards
val AxisOutline = Color(0xFFE2E8F0) // Subtle Light Border

