# AXIS — Personal Execution System

AXIS is a high-performance personal execution system built on the core product philosophy of **Plan → Execute → Review**.

This repository contains the complete AXIS Android client engineered with beautiful, native Jetpack Compose and clean architecture.

---

## 🎨 Brand Identity & Logo system

The official AXIS visual identity has been fully integrated into the Android client. The logo features a high-precision, four-pointed celestial star centered in a segmented circular compass ring with micro-gaps. The branding includes a custom display typography with a modern minimalist lambda-styled 'A' shape.

### Reference Asset Versions Created:

1. **Light Symbol-Only Vector (White):**
   - **File Path:** `app/src/main/res/drawable/ic_axis_symbol_light.xml`
   - **Purpose:** Used for adaptive app icons (Launcher Foreground) and launch screens demanding white on dark backgrounds to maximize visual clarity and high-contrast styling.
   - **Design:** Custom-designed 4-pointed star inside a 4-gapped circle utilizing balanced, scalable coordinate geometry.

2. **Dark Symbol-Only Vector (Charcoal):**
   - **File Path:** `app/src/main/res/drawable/ic_axis_symbol_dark.xml`
   - **Purpose:** Used for high-contrast representations over light backgrounds, documents, or in-app custom graphic elements.
   - **Color:** Premium Brand Charcoal (`#111111`).

3. **Full Logo Version (Dark):**
   - **File Path:** `app/src/main/res/drawable/ic_axis_full_logo_dark.xml`
   - **Purpose:** Positioned elegantly at the top of the white-first Login screen (`LoginScreen.kt`).
   - **Design:** Seamlessly integrates the symbol and the geometric custom brand text `A X I S` with a custom lambda chevron for the character 'A'.

4. **Full Logo Version (Light):**
   - **File Path:** `app/src/main/res/drawable/ic_axis_full_logo_light.xml`
   - **Purpose:** Rendered in high-contrast solid white for dark mode cards, websites, and dark backgrounds.

---

## 🏗️ Technical Architecture of Vector Logos

To ensure perfect clarity across all device densities (MDPI to XXXHDPI) without relying on blurry PNG assets, all AXIS logos are custom-crafted using standard vector geometry.

### Precision Mathematical Definitions:
* **Viewport:** Balanced $108 \times 108$ canvas.
* **Core Star:** Calculated as a non-zero compound path where the outer contour is drawn clockwise and the inner contour is drawn counter-clockwise to produce an infinitely sharp hollow center.
* **Segmented Ring:** Rendered as four exact clock arcs with a radius of $28.0$ and line-weight of $3.2$ for high clarity at tiny sizes (e.g. $48\times 48$). Gaps are mathematically aligned to allow the star points to pierce through standard layout barriers.

---

## 🚀 Release Configuration Highlights

- **Adaptive App Icons:** Confirmed and mapped using standard manifest configurations referencing `ic_launcher_foreground` (containing the crisp safe-padded AXIS symbol) and `ic_launcher_background` (featuring a modern gradient from slate black `#0A0B0E` to deep charcoal grey `#1E202B`).
- **White-First UI Safety:** The clean layout, white menus, and responsive inputs are fully preserved.
- **Splash / Launch System:** Supported naturally via Android 12+ adaptive splash, displaying the official logo seamlessly upon device boot.
