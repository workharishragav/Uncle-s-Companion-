package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PlannerDatabase
import com.example.data.model.*
import com.example.data.repository.PlannerRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalCoroutinesApi::class)
class PlannerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PlannerRepository
    private val calendar = Calendar.getInstance()

    // Active selected date formatted as "YYYY-MM-DD"
    private val _selectedDate = MutableStateFlow(getCurrentDateString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    // Login State
    private val prefs = application.getSharedPreferences("axis_auth_preferences", android.content.Context.MODE_PRIVATE)

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loginType = MutableStateFlow(prefs.getString("login_type", "") ?: "") // "Google", "Apple", "Demo"
    val loginType: StateFlow<String> = _loginType.asStateFlow()

    fun login(type: String) {
        _isLoggedIn.value = true
        _loginType.value = type
        prefs.edit().putBoolean("is_logged_in", true).putString("login_type", type).apply()
    }

    fun logout() {
        _isLoggedIn.value = false
        _loginType.value = ""
        prefs.edit().putBoolean("is_logged_in", false).putString("login_type", "").apply()
    }

    // --- Top 3 Daily Primary Outcomes State ---
    private val _outcome1 = MutableStateFlow("")
    val outcome1 = _outcome1.asStateFlow()

    private val _outcome2 = MutableStateFlow("")
    val outcome2 = _outcome2.asStateFlow()

    private val _outcome3 = MutableStateFlow("")
    val outcome3 = _outcome3.asStateFlow()

    private val _outcomeCompleted1 = MutableStateFlow(false)
    val outcomeCompleted1 = _outcomeCompleted1.asStateFlow()

    private val _outcomeCompleted2 = MutableStateFlow(false)
    val outcomeCompleted2 = _outcomeCompleted2.asStateFlow()

    private val _outcomeCompleted3 = MutableStateFlow(false)
    val outcomeCompleted3 = _outcomeCompleted3.asStateFlow()

    // Calendar week and month trackers for goal contexts
    val currentYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val currentMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1) // 1-based Month
    val currentWeekOfYear = MutableStateFlow(calendar.get(Calendar.WEEK_OF_YEAR))

    init {
        val database = PlannerDatabase.getDatabase(application)
        repository = PlannerRepository(database.plannerDao)

        loadOutcomesForDate(getCurrentDateString())

        // Initialize routines for today
        viewModelScope.launch {
            repository.initializeRoutineForDateIfEmpty(getCurrentDateString())
        }
    }

    // --- Dynamic Flow Computations reactively updating when selectedDate/month/week change ---

    // Today's Routine Activities
    val dailyRoutines: StateFlow<List<RoutineActivity>> = _selectedDate
        .flatMapLatest { date ->
            repository.getRoutineActivitiesByDate(date)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Today's Nightly Reflection
    val nightlyReflection: StateFlow<NightlyReflection?> = _selectedDate
        .flatMapLatest { date ->
            repository.getNightlyReflectionByDate(date)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Monthly Goals for selected month/year
    val monthlyGoals: StateFlow<List<MonthlyGoal>> = combine(currentYear, currentMonth) { year, month ->
        Pair(year, month)
    }.flatMapLatest { (year, month) ->
        repository.getMonthlyGoals(year, month)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Weekly Goals for selected week/year
    val weeklyGoals: StateFlow<List<WeeklyGoal>> = combine(currentYear, currentWeekOfYear) { year, week ->
        Pair(year, week)
    }.flatMapLatest { (year, week) ->
        repository.getWeeklyGoals(year, week)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All Tasks (for lists)
    val allTasks: StateFlow<List<Task>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Weekly Scheduled Tasks
    val weeklyTasks: StateFlow<List<Task>> = repository.weeklyScheduledTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // RPM Pillars List
    val rpmPillars: StateFlow<List<RpmPillar>> = repository.allRpmPillars
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Date Controllers ---

    fun changeSelectedDate(dateString: String) {
        _selectedDate.value = dateString
        syncCalendarFromDateString(dateString)
        loadOutcomesForDate(dateString)
        viewModelScope.launch {
            repository.initializeRoutineForDateIfEmpty(dateString)
        }
    }

    private fun loadOutcomesForDate(date: String) {
        _outcome1.value = prefs.getString("outcome_1_$date", "") ?: ""
        _outcome2.value = prefs.getString("outcome_2_$date", "") ?: ""
        _outcome3.value = prefs.getString("outcome_3_$date", "") ?: ""
        _outcomeCompleted1.value = prefs.getBoolean("outcome_completed_1_$date", false)
        _outcomeCompleted2.value = prefs.getBoolean("outcome_completed_2_$date", false)
        _outcomeCompleted3.value = prefs.getBoolean("outcome_completed_3_$date", false)
    }

    fun saveOutcome(index: Int, text: String) {
        val date = _selectedDate.value
        prefs.edit().putString("outcome_${index}_$date", text).apply()
        when (index) {
            1 -> _outcome1.value = text
            2 -> _outcome2.value = text
            3 -> _outcome3.value = text
        }
    }

    fun toggleOutcomeCompleted(index: Int) {
        val date = _selectedDate.value
        val currentCompleted = when (index) {
            1 -> _outcomeCompleted1.value
            2 -> _outcomeCompleted2.value
            3 -> _outcomeCompleted3.value
            else -> false
        }
        val newCompleted = !currentCompleted
        prefs.edit().putBoolean("outcome_completed_${index}_$date", newCompleted).apply()
        when (index) {
            1 -> _outcomeCompleted1.value = newCompleted
            2 -> _outcomeCompleted2.value = newCompleted
            3 -> _outcomeCompleted3.value = newCompleted
        }
    }

    fun selectPreviousDay() {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = format.parse(_selectedDate.value) ?: Date()
        val cal = Calendar.getInstance().apply { time = date }
        cal.add(Calendar.DAY_OF_YEAR, -1)
        changeSelectedDate(format.format(cal.time))
    }

    fun selectNextDay() {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = format.parse(_selectedDate.value) ?: Date()
        val cal = Calendar.getInstance().apply { time = date }
        cal.add(Calendar.DAY_OF_YEAR, 1)
        changeSelectedDate(format.format(cal.time))
    }

    // --- Actions Triggering Database Mutations ---

    // --- RPM Pillars Operations ---
    fun addRpmPillar(pillar: RpmPillar) {
        viewModelScope.launch { repository.insertRpmPillar(pillar) }
    }

    fun updateRpmPillar(pillar: RpmPillar) {
        viewModelScope.launch { repository.updateRpmPillar(pillar) }
    }

    fun deleteRpmPillar(id: Int) {
        viewModelScope.launch { repository.deleteRpmPillar(id) }
    }

    // --- Monthly Goal Operations ---
    fun addMonthlyGoal(content: String, goalNum: Int) {
        viewModelScope.launch {
            repository.insertMonthlyGoal(
                MonthlyGoal(
                    year = currentYear.value,
                    month = currentMonth.value,
                    goalNumber = goalNum,
                    content = content
                )
            )
        }
    }

    fun toggleMonthlyGoal(goal: MonthlyGoal) {
        viewModelScope.launch {
            repository.updateMonthlyGoal(goal.copy(isCompleted = !goal.isCompleted))
        }
    }

    fun deleteMonthlyGoal(id: Int) {
        viewModelScope.launch { repository.deleteMonthlyGoal(id) }
    }

    // --- Weekly Goal Operations ---
    fun addWeeklyGoal(content: String, goalNum: Int, isNextWeek: Boolean = false) {
        viewModelScope.launch {
            repository.insertWeeklyGoal(
                WeeklyGoal(
                    year = currentYear.value,
                    weekOfYear = currentWeekOfYear.value,
                    goalNumber = goalNum,
                    content = content,
                    isNextWeek = isNextWeek
                )
            )
        }
    }

    fun toggleWeeklyGoal(goal: WeeklyGoal) {
        viewModelScope.launch {
            repository.updateWeeklyGoal(goal.copy(isCompleted = !goal.isCompleted))
        }
    }

    fun deleteWeeklyGoal(id: Int) {
        viewModelScope.launch { repository.deleteWeeklyGoal(id) }
    }

    // --- Task Operations ---
    fun addTask(
        title: String,
        category: String = "General",
        priority: String = "B",
        associatedDay: String? = null,
        rpmPillarId: Int? = null,
        duration: String = ""
    ) {
        viewModelScope.launch {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val dateMillis = format.parse(_selectedDate.value)?.time ?: System.currentTimeMillis()
            repository.insertTask(
                Task(
                    title = title,
                    targetDate = dateMillis,
                    category = category,
                    priority = priority,
                    associatedDay = associatedDay,
                    rpmPillarId = rpmPillarId,
                    duration = duration
                )
            )
        }
    }

    fun toggleTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun updateTaskFull(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun deleteTask(id: Int) {
        viewModelScope.launch { repository.deleteTask(id) }
    }

    // --- Routine Activity Operations ---
    fun toggleRoutineActivity(activity: RoutineActivity) {
        viewModelScope.launch {
            repository.updateRoutineActivity(activity.copy(isCompleted = !activity.isCompleted))
        }
    }

    // --- Nightly Reflection Operations ---
    fun saveNightlyReflection(
        planVsActual: String,
        didVictoryHour: Boolean,
        didSavers: Boolean,
        rating: Int,
        expensesLogged: Boolean,
        portfolioChecked: Boolean,
        notes: String
    ) {
        viewModelScope.launch {
            repository.insertNightlyReflection(
                NightlyReflection(
                    date = _selectedDate.value,
                    planVsActual = planVsActual,
                    didVictoryHour = didVictoryHour,
                    didSavers = didSavers,
                    rating = rating,
                    expensesLogged = expensesLogged,
                    portfolioChecked = portfolioChecked,
                    notes = notes
                )
            )
        }
    }

    // --- Utilities ---

    private fun getCurrentDateString(): String {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return format.format(Date())
    }

    private fun syncCalendarFromDateString(dateString: String) {
        try {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = format.parse(dateString) ?: return
            val cal = Calendar.getInstance().apply { time = date }
            currentYear.value = cal.get(Calendar.YEAR)
            currentMonth.value = cal.get(Calendar.MONTH) + 1
            currentWeekOfYear.value = cal.get(Calendar.WEEK_OF_YEAR)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
